# Method reference

Every method returns a promise and takes an optional trailing
`RequestOptions`:

```ts
type RequestOptions = {
  apiKey?: string; // act as this customer for one call
  creatorId?: string; // or this roster account; never both; integrator only
  signal?: AbortSignal;
  timeoutMs?: number; // default 30000
  retry?: boolean; // false disables retries for this call
};
```

`auth.createToken` accepts only `signal`.

Precedence for naming the customer: per-call options, then
`forCustomer(...)`, then the constructor or environment.

## Client

```ts
import Laylo from "@laylo.com/node";

const laylo = new Laylo({
  userId, // LAYLO_USER_ID
  accessKey, // LAYLO_ACCESS_KEY
  secretKey, // LAYLO_SECRET_KEY
  apiKey, // LAYLO_API_KEY, or:
  creatorId, // LAYLO_CREATOR_ID
  source, // optional, identifies your integration (X-Laylo-Source)
  timeoutMs, // default 30000
  maxRetries, // default 2
});

laylo.forCustomer("customer-api-key");
laylo.forCustomer({ apiKey: "..." });
laylo.forCustomer({ creatorId: "..." });

// For an account's own data, the API key alone (or LAYLO_API_KEY with no
// LAYLO_USER_ID, LAYLO_ACCESS_KEY, or LAYLO_SECRET_KEY set):
const own = new Laylo({ apiKey });
```

With none of `userId`, `accessKey`, and `secretKey` set, the client sends only
`X-Api-Key`, with no access token. It is limited to 20 requests a minute per
account, `creatorId` throws `LayloConfigurationError` wherever it's passed,
`customers.list()` throws `PermissionError`, and `auth.createToken()` rejects.
Setting some but not all of the three is a construction error.

Each key-only call also needs a permission on the key: "write" for
`fans.subscribe`, `conversions.events.track`, and `messages.sms.send`, "read"
for everything else. "write" doesn't grant "read", and a key with none stored
can only read (an empty list allows nothing). A missing one throws `PermissionError`
(`This API key does not have the "write" permission`); use a key that has it.

CommonJS: `const { Laylo } = require("@laylo.com/node");`

## keys.verify()

Checks the customer resolves. Pass `{ apiKey }` in the options to check a key
a customer just gave you before you store it.

Returns `{ apiKeyStatus: "valid" | "not_provided", message: string }`. An
invalid key throws `AuthenticationError` with `apiKeyStatus === "invalid"`. A
valid key on an account without a paid plan, or on a locked account, throws `PermissionError`.

## customers.list()

Returns the accounts under the integration's own Laylo account, sorted by
display name:

```ts
type CustomerAccount = {
  id: string;
  displayName: string | null;
  username: string | null;
  createdAt: number | null;
};
// returns CustomerAccount[]
```

`id` is the value `forCustomer({ creatorId })` accepts. `createdAt` is epoch
milliseconds. Needs integrator credentials; with only an API key it throws
`PermissionError`.

## drops.list()

Returns the customer's active public drops:

```ts
type Drop = {
  id: string;
  title: string;
  description: string | null;
  imageUrl: string | null;
  isMultidrop: boolean;
  createdAt: number; // epoch ms
  endDate: number | null; // drop day, epoch ms
  dropDayMessage: string | null; // sent to fans on the drop day
};
// returns Drop[]
```

## conversions.list(params?)

| Param              | Type                                     |
| ------------------ | ---------------------------------------- |
| `action`           | `ConversionAction \| ConversionAction[]` |
| `relatedProductId` | `string`                                 |

Returns `{ id: string; action: ConversionAction; name: string }[]`. `id` has
the form `customerId:action:name`. An empty `action` array throws. Leave the
param out to include every action.

## conversions.counts.list(params?)

| Param       | Type                                     | Default            |
| ----------- | ---------------------------------------- | ------------------ |
| `action`    | `ConversionAction \| ConversionAction[]` | all actions        |
| `startDate` | `Date \| string` (inclusive)             | 28 days before end |
| `endDate`   | `Date \| string` (inclusive)             | now                |

Returns:

```ts
type ConversionCountsReport = {
  startDate: string; // the window actually applied, ISO UTC
  endDate: string;
  counts: {
    action: ConversionAction;
    total: number;
    series: { time: string; count: number }[]; // one per day, oldest first
  }[];
};
```

Actions with no events in the window are omitted. Days follow the Pacific
calendar. Counts are events, not distinct fans.

## conversions.events.track(event)

```ts
type TrackConversionEventInput = {
  action: ConversionAction;
  name: string; // non-empty, e.g. "VIP ticket"
  timestamp: Date | string; // when it happened
  metadata: {
    uniqueId?: string; // idempotency key; repeats are merged
    productId?: string;
    currency?: string;
    totalPrice?: number;
    totalCost?: number;
    [key: string]: unknown;
  };
  user: {
    // need one of email, phone, or fingerprintId
    email?: string;
    phone?: string; // E.164
    fingerprintId?: string;
    isAnonymous?: boolean;
    emailMarketingConsent?: boolean;
    smsMarketingConsent?: boolean;
  };
  consentGrantedAt?: string; // ISO 8601 with offset
  sessionId?: string;
  source?: string;
};
```

Returns `{ status: "success" | "failure", tracked }`. `tracked` echoes the
event with contact fields replaced by `hasEmail` and `hasPhone` flags.

## fans.isSubscribed(contact) / fans.isUnsubscribed(contact)

`contact` is exactly one of `{ email }` or `{ phone }` (E.164). Each returns a
`boolean`. `isUnsubscribed` is true only for a contact who subscribed at some
point and has since opted out. A contact who never subscribed is false for
both.

## fans.segments.count(filters)

| Filter                  | Type                | Notes                           |
| ----------------------- | ------------------- | ------------------------------- |
| `signUpType`            | `"sms" \| "email"`  | required                        |
| `dropIds`               | `string[]`          | fans who purchased any of these |
| `excludedDropIds`       | `string[]`          |                                 |
| `conversionIds`         | `string[]`          | from `conversions.list()`       |
| `excludedConversionIds` | `string[]`          |                                 |
| `locations`             | `SegmentLocation[]` |                                 |
| `excludedLocations`     | `SegmentLocation[]` |                                 |
| `signedUpAfter`         | `Date \| string`    | inclusive                       |
| `signedUpBefore`        | `Date \| string`    | exclusive                       |

`SegmentLocation` is one of `{ country }`, `{ country, state }`, or
`{ country, state, city, radius? }`. Array filters match any of their values,
and an empty array turns the filter off.

- `country` takes an ISO 3166-1 alpha-2 code such as `US` or `FR`.
- `state` takes a state or province code for the US, Canada, and Australia
  (`NY`, `ON`, `NSW`). Elsewhere, use the region's name.
- `city` takes the city's name. Add `radius` to include everywhere within
  that many miles of the city.

Returns a `number`: the count of matching fans.

## fans.subscribe(fan)

One of:

```ts
type SubscribeFanInput =
  | {
      email: string;
      emailMarketingConsent: true;
      consentGrantedAt: Date | string;
      dropId?: string;
    }
  | {
      phone: string;
      smsMarketingConsent: true;
      consentGrantedAt: Date | string;
      dropId?: string;
    }
  | {
      email: string;
      emailMarketingConsent: true;
      phone: string;
      smsMarketingConsent: true;
      consentGrantedAt: Date | string;
      dropId?: string;
    };
```

With both, each channel is subscribed and the two records are linked as the
same person. Each keeps its own id, returned as `emailFanId` and `phoneFanId`.

`consentGrantedAt` becomes the sign-up time and can't be in the future.
`dropId` also RSVPs the fan. It must be one of the customer's drops, or the
call throws `NotFoundError` and writes nothing. Subscribing an existing fan
refreshes their record and clears any earlier unsubscribe.

Returns:

```ts
type SubscribeFanResponse = {
  subscribed: boolean;
  emailFanId?: string; // only when email was given
  phoneFanId?: string; // only when phone was given
  rsvp?: { dropId: string; status: "confirmed" }; // only when dropId was given
};
```

## messages.sms.send(sms)

```ts
type SendSmsRequest = {
  message: string; // up to 1,600 characters, same text for every recipient
  to: string | string[]; // E.164; an array holds 1 to 200 numbers
};
```

Only numbers that currently subscribe to the customer are texted. An invalid
number, or one in a country Laylo doesn't send SMS to, throws
`BadRequestError` and nothing is sent. An empty `to` array or more than 200
numbers throws `LayloConfigurationError` before any request. A customer
without a Laylo phone number throws `ConflictError`.

Returns:

```ts
type SendSmsResponse = {
  queued: number; // messages accepted; billed per SMS segment, not per message
  skipped: {
    index: number; // position in `to`; 0 when `to` is a string
    reason: "not_subscribed" | "duplicate" | "queue_failed";
  }[];
};
```

It isn't retried on a 5xx. Retrying only the `queue_failed` recipients is safe.

## auth.createToken()

Returns `{ access_token: string; expires_in: number; token_type: "Bearer" }`.
Only needed to call the HTTP API directly. The SDK handles tokens itself.
Rejects with `LayloConfigurationError` on a client with only an API key.

## ConversionAction values

`PURCHASE`, `STORE_PURCHASE`, `TICKET_PURCHASE`, `CHECK_IN`, `ADD_TO_CART`,
`LINK_CLICK`, `UPSELL_CLICK`, `UPSELL_REMINDER_CLICK`, `VIP_CLICK`, `RSVP`,
`OPT_OUT`, `DIRECT_MESSAGE`, `CALL`, `FOLLOW`, `SOCIAL_ENGAGEMENT`,
`WAITLIST_SIGNUP`, `SECONDARY_LISTING_CREATED`, `ABANDONED_CART_CLICK`,
`TICKET_SALES_CLICK`, `ABANDONED_CART_CREATED`, `ABANDONED_CART_UPDATED`,
`FORM_SUBMISSION`, `QUESTION_RESPONSE`

## Errors

All errors extend `LayloError`. API responses throw `LayloAPIError`
subclasses: `BadRequestError` (400), `AuthenticationError` (401),
`PermissionError` (403), `NotFoundError` (404), `MethodNotAllowedError`
(405), `ConflictError` (409), `RateLimitError` (429, `retryAfter`),
`NotImplementedError` (501), `ServerError` (5xx). Non-HTTP errors are
`LayloConnectionError`, `LayloTimeoutError`, and `LayloConfigurationError`
(bad client or call setup, thrown before any request).

```ts
import { LayloAPIError, RateLimitError } from "@laylo.com/node";
```
